package com.library.demo.models;

public enum Role {
    USER,
    ADMIN
}